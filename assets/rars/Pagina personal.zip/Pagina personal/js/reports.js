const reportTableBody = document.querySelector("#reportTable tbody");
let records = JSON.parse(localStorage.getItem("attendanceRecords")) || [];

function generateReport() {
  const filterType = document.getElementById("filterType").value;
  const startDate = new Date(document.getElementById("filterDate").value);

  if (!startDate) return;

  let filtered = records.filter(r => {
    let recordDate = new Date(r.date);
    let diff = (recordDate - startDate) / (1000 * 60 * 60 * 24);

    if (filterType === "week") return diff >= 0 && diff < 7;
    if (filterType === "month") return recordDate.getMonth() === startDate.getMonth() && recordDate.getFullYear() === startDate.getFullYear();
  });

  renderTable(filtered);
}

function renderTable(data) {
  reportTableBody.innerHTML = "";

  data.forEach(record => {
    const row = document.createElement("tr");
    row.innerHTML = `
      <td>${record.date}</td>
      <td>${record.employee}</td>
      <td>${record.type}</td>
      <td>${record.details || ""}</td>
    `;
    reportTableBody.appendChild(row);
  });
}

function exportToExcel() {
  const wb = XLSX.utils.book_new();
  const ws = XLSX.utils.table_to_sheet(document.getElementById("reportTable"));
  XLSX.utils.book_append_sheet(wb, ws, "Report");
  XLSX.writeFile(wb, "Attendance_Report.xlsx");
}

function exportToPDF() {
  const { jsPDF } = window.jspdf;
  const doc = new jsPDF();
  doc.text("Attendance Report", 10, 10);
  let y = 20;

  [...reportTableBody.rows].forEach(row => {
    let rowData = [...row.cells].map(cell => cell.textContent).join(" | ");
    doc.text(rowData, 10, y);
    y += 10;
  });

  doc.save("Attendance_Report.pdf");
}
