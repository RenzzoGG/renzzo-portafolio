// Verifica si hay un usuario logueado
const currentUser = JSON.parse(localStorage.getItem("loggedInUser"));
if (!currentUser) {
  alert("Please log in first.");
  window.location.href = "login.html";
}

// Muestra el nombre del usuario en pantalla
document.getElementById("welcomeMessage").innerText = `Welcome, ${currentUser.username} (${currentUser.role})`;

// Si el usuario es ejecutivo, ocultamos el formulario
if (currentUser.role === "executive") {
  const form = document.getElementById("attendanceForm");
  if (form) form.style.display = "none";
}

// Función para cerrar sesión
function logout() {
  localStorage.removeItem("loggedInUser");
  window.location.href = "login.html";
}

// Cambia visibilidad del campo 'details' si se selecciona "Permission"
document.getElementById("type").addEventListener("change", function() {
  const type = this.value;
  const detailsInput = document.getElementById("details");
  if (type === "Permission") {
    detailsInput.style.display = "inline";
    detailsInput.required = true;
  } else {
    detailsInput.style.display = "none";
    detailsInput.value = "";
    detailsInput.required = false;
  }
});

// Manejo del formulario
document.getElementById("attendanceForm").addEventListener("submit", function(e) {
  e.preventDefault();

  const employee = document.getElementById("employee").value;
  const date = document.getElementById("date").value;
  const type = document.getElementById("type").value;
  const details = document.getElementById("details").value;

  const record = { employee, date, type, details };
  
  let records = JSON.parse(localStorage.getItem("attendanceRecords")) || [];
  records.push(record);
  localStorage.setItem("attendanceRecords", JSON.stringify(records));

  appendRecordToList(record);
  this.reset();
  document.getElementById("details").style.display = "none";
});

// Mostrar registros previos al cargar la página
window.addEventListener("load", () => {
  const records = JSON.parse(localStorage.getItem("attendanceRecords")) || [];
  records.forEach(appendRecordToList);
});

// Agrega un registro a la lista visible
function appendRecordToList(record) {
  const li = document.createElement("li");
  li.textContent = `${record.date} - ${record.employee} - ${record.type} ${record.details ? `(${record.details})` : ''}`;
  document.getElementById("attendanceList").appendChild(li);
}
