document.getElementById("loginForm").addEventListener("submit", function (e) {
  e.preventDefault();

  const username = document.getElementById("username").value;
  const role = document.getElementById("role").value;

  if (!username || !role) {
    alert("Please enter both username and role.");
    return;
  }

  const user = { username, role };
  localStorage.setItem("loggedInUser", JSON.stringify(user));

  // 👉 Redirige al dashboard principal
  window.location.href = "dashboard.html";
});
