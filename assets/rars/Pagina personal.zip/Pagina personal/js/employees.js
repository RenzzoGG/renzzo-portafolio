const form = document.getElementById("employeeForm");
const list = document.getElementById("employeeList");

// Cargar empleados guardados en localStorage
let employees = JSON.parse(localStorage.getItem("employees")) || [];

// Mostrar los empleados en la lista
function renderList() {
  list.innerHTML = ""; // limpiar lista
  employees.forEach((emp, index) => {
    const li = document.createElement("li");
    li.textContent = `${emp.name} – ${emp.position} – ${emp.email}`;
    list.appendChild(li);
  });
}

// Guardar nuevo empleado
form.addEventListener("submit", (e) => {
  e.preventDefault();

  const employee = {
    name: form.name.value.trim(),
    position: form.position.value.trim(),
    email: form.email.value.trim()
  };

  employees.push(employee);
  localStorage.setItem("employees", JSON.stringify(employees));

  form.reset(); // limpiar el formulario
  renderList(); // actualizar lista
});

// Mostrar empleados al cargar la página
renderList();
